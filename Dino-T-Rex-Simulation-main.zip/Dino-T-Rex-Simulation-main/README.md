# Dino-T-Rex-Simulation
Dino T-Rex Game Simulation using a Multi-Agent System

- from scratch

- using Jade framework (+ GUI build with JavaFX)

