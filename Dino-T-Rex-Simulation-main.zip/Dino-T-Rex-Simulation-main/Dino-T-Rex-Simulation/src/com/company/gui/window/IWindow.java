package com.company.gui.window;

import javafx.scene.Scene;

public interface IWindow {

    Scene create();
}
