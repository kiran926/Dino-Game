package com.company;

public enum Action {
    SQUAT,
    JUMP,
    DIE,
    SEND_BIRD,
    SEND_CACTUS,
}
