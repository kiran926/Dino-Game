package game;

public enum Obstacle {
    BIRD, CACTUS
}
