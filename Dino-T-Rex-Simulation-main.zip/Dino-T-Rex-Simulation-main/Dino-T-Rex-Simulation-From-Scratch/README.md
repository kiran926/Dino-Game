To run the app:

*src >> game >> GameSimulation*
